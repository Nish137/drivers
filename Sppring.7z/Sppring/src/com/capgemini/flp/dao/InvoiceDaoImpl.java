package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.dto.CombinedObject;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.dto.Order;
import com.capgemini.flp.exception.InvoiceException;




@Repository
public class InvoiceDaoImpl implements InvoiceDao {
	@PersistenceContext 
	EntityManager entityManager;
		
		
	

	
		@Override
		public CombinedObject getInvoice(int productid, int orderid)
				throws InvoiceException,NullPointerException {
			Order a=entityManager.find(Order.class, 1001);
			MerchantProduct b=entityManager.find(MerchantProduct.class,100);
//			System.out.println(a.getCustomerEmailId());
//			System.out.println(b.getProduct_Category());
			CombinedObject a1 = new CombinedObject();
			a1.setM(b);
			a1.setO(a);
			
			return a1;
		
			
		}
		}


