package com.capgemini.flp.service;

import java.util.List;

import com.capgemini.flp.dto.CombinedObject;
import com.capgemini.flp.exception.InvoiceException;

public interface InvoiceService {

	public CombinedObject getInvoice(int productid, int orderid) throws InvoiceException;

}
