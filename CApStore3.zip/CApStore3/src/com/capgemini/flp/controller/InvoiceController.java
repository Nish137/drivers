package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.CombinedObject;
import com.capgemini.flp.exception.InvoiceException;
import com.capgemini.flp.service.InvoiceService;

@Controller

public class InvoiceController {
	@Autowired
	InvoiceService service;
	
	@RequestMapping ("/hi")
	public ModelAndView abc(){
		System.out.println("Hello");
	
 int productid=100;
		int orderid=1001;
		
		try {
			CombinedObject a=service.getInvoice(productid,orderid);
//		for ( Object a1 : a) {
			System.out.println(a.getM().getMerchant_email_Id());
//		}	
		 
			return new ModelAndView("index","abc",a);
		} catch (InvoiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("hello","abc","abc");
		
		
	}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/*
	public ModelAndView showIndex() throws Exception {
		ModelAndView mv=new ModelAndView("index");
		try{
			List<Invoice> invoice=service.getInvoice();
			mv.addObject("invoices",invoice);

		}catch (Exception e){
		 throw new InvoiceException (e.getMessage());
		}
		return mv;
		
	}
	 @RequestMapping("/addInvoice")
	 public ModelAndView showAdd(){
		 
		 ModelAndView mv=new ModelAndView("add");
		 try{
				List<Invoice> invoice=service.getInvoice();
				mv.addObject("invoices",invoice);

			}catch (Exception e){
			 try {
				throw new InvoiceException (e.getMessage());
			} catch (InvoiceException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
			return mv;
		 
	 }*/

	/* @RequestMapping("/add")
  public ModelAndView addEmployee(@Valid @ModelAttribute Invoice invoice,BindingResult result){
	  ModelAndView mv=null;
	  
	  if(result.hasErrors()){
		  
		  
		  
		  
		    mv=new  ModelAndView("add");
		   mv.addObject("invoices",invoice);
		   
	  }
	  else{
		   
	  }
	  return mv;
  }
}*/


	/* @RequestMapping("/addEmployee")
	 public String showAdd(Model model){
		 
		 model.addAttribute("employee",new Employee());
		return "add";
		 
	 }
	 @RequestMapping("/add")
  public ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result){
	  ModelAndView mv=null;
	  
	  if(result.hasErrors()){
		  
		  
		  
		  
		    mv=new  ModelAndView("add");
		   mv.addObject("employee",employee);
		   
	  }
	  else{
		   
	  }
	  return mv;
  }*/

