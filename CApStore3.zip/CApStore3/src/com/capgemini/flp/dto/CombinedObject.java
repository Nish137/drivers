package com.capgemini.flp.dto;

public class CombinedObject {

	MerchantProduct m;
	Order o;
	public MerchantProduct getM() {
		return m;
	}
	public void setM(MerchantProduct m) {
		this.m = m;
	}
	public Order getO() {
		return o;
	}
	public void setO(Order o) {
		this.o = o;
	}
	
}
