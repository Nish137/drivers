package com.capgemini.flp.dao;

public interface OrderDao {

}
